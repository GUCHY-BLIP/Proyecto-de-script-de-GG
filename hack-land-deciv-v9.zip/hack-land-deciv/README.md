# Hack Land — DeCiv Redux Edition

Port of the Hack Land mod for the DeCiv Redux ruleset.

- Resources adapted to DeCiv Redux (33 Luxury, 8 Strategic, 9 Bonus)
- Promotions adapted to DeCiv Redux (106 promotions)
- Spawner buildings removed (not applicable to DeCiv unit types)
- All other hack buildings preserved
